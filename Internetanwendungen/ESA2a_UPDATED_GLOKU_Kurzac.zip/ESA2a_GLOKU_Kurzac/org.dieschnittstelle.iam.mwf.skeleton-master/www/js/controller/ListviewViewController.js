/**
 * @author Jörn Kreutel
 * @quelle Tutorial.pdf, Übungsdokument.pdf
 * @modifiziert <25.05.23> N.Kurzac, D. Glowacki
 * <N.Kurzac>
 *     deleteItemDialog()
 * <D.Glowacki>
 *     switchCrudScope()
 */
import {mwf} from "../Main.js";
import {entities} from "../Main.js";

export default class ListviewViewController extends mwf.ViewController {
    args;
    root;
    items;
    addNewMediaItemElement;
    switchCRUDScope;

    constructor() {
        super();

        console.log("ListviewViewController()");

    }

    /*
     * for any view: initialise the view
     */
    async oncreate() {
       this.addNewMediaItemElement = this.root.querySelector("#addNewMediaItem");

       this.addNewMediaItemElement.onclick = (() => {this.createNewItem();});

       this.switchCRUDScope = this.root.querySelector("#switchCRUDScope");

       this.switchCRUDScope.onclick = (() => {this.switchScope();});

        entities.MediaItem.readAll().then((items) => {
            this.initialiseListview(items);
        });
        // call the superclass once creation is done
        super.oncreate();
    }
    createNewItem() {
        var newItem = new entities.MediaItem("","https://placekitten.com/100/100");
        this.showDialog("mediaItemDialog",{
            item: newItem,
            actionBindings: {
                submitForm: ((event) => {
                    event.original.preventDefault();
                    newItem.create().then(() => {
                        this.addToListview(newItem);
                    });
                    this.hideDialog();
                })
            }
        });
    }

    onListItemSelected(itemobj, listviewid) {
        this.nextView("mediaReadview",{item: itemobj});

    }

    async onReturnFromNextView(nextviewid, returnValue, returnStatus) {
        // TODO: check from which view, and possibly with which status, we are returning, and handle returnValue accordingly
        if (nextviewid == "mediaReadview" && returnValue &&
            returnValue.deletedItem) {
            this.removeFromListview(returnValue.deletedItem._id);
        }

    }

    deleteItem(item) {
        item.delete(() => {
            this.removeFromListview(item._id);
        });
    }
    editItem(item) {
        this.showDialog("mediaItemDialog", {
            item: item,
            actionBindings: {
                submitForm: ((event) => {
                    event.original.preventDefault();
                    item.update().then(() => {
                        this.updateInListview(item._id,item);
                    });
                    this.hideDialog();
                }),
                deleteItem: ((event) => {
                    this.deleteItem(item);
                    this.hideDialog();
                })

            }
        });
    }

    deleteItemDialog(item){
        this.showDialog("mediaItemDeleteDialog", {
            item: item,
            actionBindings: {
                deleteItem: ((event) => {
                    this.deleteItem(item);
                    this.hideDialog();
                }),
                cancel: ((event) => {
                    this.hideDialog();
                })
            }
        });
    }
    switchScope() {
        if (this.application.currentCRUDScope === "local") {
            this.application.switchCRUD("remote");
        } else {
            this.application.switchCRUD("local");
        }

        this.root.querySelector("#CRUDScopeStatus").innerHTML = this.application.currentCRUDScope;
        entities.MediaItem.readAll().then((items) => {
            this.initialiseListview(items);
        });

    }

}

